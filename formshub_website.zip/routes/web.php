<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\IndexController;
use App\http\Controllers\PricingController;
use App\http\Controllers\KnowledgeBaseController;
use App\http\Controllers\ContactController;
use App\http\Controllers\ProductController;
use App\Http\Controllers\LocaleController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// home
Route::get('/',[IndexController::class,'index'])->name('home');
// pricing
Route::get('/pricing', [PricingController::class,'index'])->name('pricing');
// features
Route::get('/features', function () {
    return view('features');
})->name('features');
// contact us
Route::get('/contact', [ContactController::class,'index'])->name('contact');
// knowledgebase
Route::get('/knowledgebase/{id?}', [KnowledgeBaseController::class,'index'])->name('knowledgebase');
// send email
Route::post('/sendemail', [ContactController::class,'sendEmail'])->name('sendemail');

// products
Route::get('/products', [ProductController::class,'index'])->name('products');
Route::post('/neworder', [ProductController::class,'orderProduct'])->name('neworder');

Route::post('/orderproduct', [ProductController::class,'orderProduct'])->name('orderproduct');


  // change language
  Route::get('setlocale/{locale}',[LocaleController::class, 'setLocale'])->name('setLocale');

//terms and conditions
Route::get('/termsandconditions',function()
{


     return view('termsandconditions');
}
)->name('terms_conditions');
//privacy policy
Route::get('/privacypolicy',function()
{

    return view('privacypolicy');
}
)->name('privacypolicy');
