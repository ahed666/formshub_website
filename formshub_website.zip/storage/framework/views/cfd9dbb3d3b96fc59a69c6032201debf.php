<?php $__env->startSection('content'); ?>

<?php
$title=trans('main.products_title');
$text=trans('main.products_text');

?>
<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header_section','data' => ['title' => $title,'text' => $text]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header_section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($text)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <section class="section">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-4 ms-auto order-2">
              <h2 class="mb-4"><?php echo e(__('main.kioskinfo_title')); ?></h2>
              <p class="mb-4"><?php echo e(__('main.kioskinfo_text')); ?></p>
            </div>
            <div class="col-md-6" data-aos="fade-right">
              <img src="<?php echo e(asset('assets/img/kiosk.jpg')); ?>" alt="Image" class="img-fluid">
            </div>
          </div>
        </div>
    </section>
      

    <section class="section">
        <div class="row justify-content-center text-center mb-5">
            <div class="col-md-5 aos-init aos-animate" data-aos="fade-up">
              <h2 class="section-heading"><?php echo e(__('main.ordernow')); ?></h2>
            </div>
          </div>
        <div class="container">
          <div class=" order-form">

                <form id="orderForm"  method="POST" action="<?php echo e(route('neworder')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="my-2 fs-3 text-black d-flex justify-content-start align-items-start">
                       <?php echo e(__('Customer Info')); ?>

                    </div>
                    <div class="row align-items-center">
                        <div class="col-md-4 col-12 ms-auto  d-flex justify-content-center">
                            <img src="<?php echo e(asset('assets/img/order2.avif')); ?>" alt="Image" class="img-formorder">
                        </div>
                        <div class="col-md-8 col-12  " >
                            
                            <div class="form-row my-2">
                                <div class="row">

                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="fname"><?php echo e(__('main.firstname')); ?></label>
                                            <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="lname"><?php echo e(__('main.lastname')); ?></label>
                                            <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-row my-2">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email"><?php echo e(__('main.email')); ?></label>
                                            <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="mobilenumber"><?php echo e(__('main.mobilenumber')); ?></label>
                                            <input pattern="^(05|5)\d{8}$" title="Please enter a valid UAE mobile phone number with either '05xxxxxxxx' or '5xxxxxxxx' " type="text" maxlength="10"  class="form-control" id="mobilenumber" name="mobilenumber" placeholder="5xxxxxxxx" required>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <input type="hidden" name="total" value="" id="total">
                    
                    <div class="form-row my-2">
                        <div class="row">

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="address"><?php echo e(__('main.city')); ?></label>
                                    <select class="form-select form-control" aria-label="Default select example" name="cityname" id="cityname">


                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->city_name); ?>"><?php echo e($city->city_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-8 col-12">
                                <div class="form-group">
                                    <label for="city"><?php echo e(__('main.address')); ?></label>
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="my-2 fs-3 text-black  d-flex justify-content-start align-items-start">
                       <?php echo e(__('Order Info')); ?>

                    </div>
                    
                    <div class="container">
                    <div class="  row   mb-3 ">
                        <?php $__currentLoopData = $devicesModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          

                            
                            <div class="col-lg-2 col-sm-12 col-md-12  align-items-center mx-2 my-1 my-sm-auto">
                                <input type="checkbox" class="btn-check" name="items[]" onchange="toggleBorder(this,<?php echo e($device->id); ?>,<?php echo e($device->price); ?>)" value="<?php echo e($device->id); ?>" id="item_<?php echo e($device->id); ?>" autocomplete="off" >
                                <label class="btn border border-1 border-dark d-flex justify-content-center items-center" for="item_<?php echo e($device->id); ?>">
                                    <img width="100" height="100" class="img-fluid" src="<?php echo e(asset($device->image)); ?>" alt="">
                                </label>
                                <div data-bs-toggle="tooltip"  data-bs-html="true" title="<?php echo e($device->device_model); ?> <?php echo e($device->name); ?>" class="custom-element  d-flex justify-content-center align-items-center   ">
                                    <span class="fs-5 text-nowrap overflow-hidden "><?php echo e($device->device_model); ?> <?php echo e($device->name); ?></span>
                                </div>
                                
                                <div class="d-flex justify-content-center mt-2 align-items-center">
                                    <span class="fs-6"><?php echo e($device->price); ?><?php echo e(__(' AED')); ?> <span class="vat"><?php echo e(__('+VAT')); ?></span></span>
                                </div>
                                
                                <div id="quantityDiv_<?php echo e($device->id); ?>" class="d-flex justify-content-center my-2 align-items-center d-none">
                                    <label class="fs-6"  for="quantity_with_stand_<?php echo e($device->id); ?>"><?php echo e(__('Quantity: ')); ?></label>
                                    <input  class="w-50 mx-2 border border-1  rounded-pill px-3 " type="number" name="quantity_<?php echo e($device->id); ?>" id="quantity_<?php echo e($device->id); ?>" value="1" min=1 onchange="changeQuantity(this,<?php echo e($device->id); ?>)">
                                </div>

                            </div>





                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center  border border-1  rounded my-3 p-2  " style="height: 50px" >
                     <span class="mx-2"><?php echo e(__('main.totalprice')); ?></span>   <span id="total_price">0</span><span class="mx-2"><?php echo e(__(' AED ')); ?> <span class="vat"><?php echo e(__('+VAT')); ?></span></span>
                    </div>

                    <div class="d-flex justify-content-center align-items-center" >
                    <button type="submit" class="btn btn-primary"><?php echo e(__('main.sendorder')); ?></button>
                    </div>
                </form>

          </div>
        </div>
    </section>




  <!-- ======= Footer ======= -->
  <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/sweetalert2@11')); ?>"></script>
  <script src="<?php echo e(asset('https://code.jquery.com/jquery-3.6.4.min.js')); ?>"></script>
    <?php if($errors->any()): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: <?php echo json_encode($errors->all(), 15, 512) ?>,
        });
    </script>
    <?php endif; ?>
    <script>

        var selectedItems=[];
        $(document).ready(function () {
            $('#contactForm').submit(function () {
                $('#submitButton').prop('disabled', true);
                $('#submitButton').prop('value',"Sending..");
            });
        });
        // errors

    // change quantity
    function changeQuantity(input,id){
        console.log(id);
        selectedItems[id].count=input.value;
        updatePrice();

    }
    // select un select item
    function toggleBorder(checkbox,id,price) {
        const label = checkbox.nextElementSibling;
        quantityDiv=document.getElementById('quantityDiv_'+id);
        quantityInput=document.getElementById('quantity_'+id);
        if (checkbox.checked) {
            label.classList.remove('border-dark');
            label.classList.add('border-primary');
            quantityDiv.classList.remove('d-none');
            quantityInput.value=1;
            selectedItems[id]={price:price,count:document.getElementById('quantity_'+id).value};
            updatePrice();

        } else {
            label.classList.remove('border-primary');
            label.classList.add('border-dark');
            quantityDiv.classList.add('d-none');
            delete selectedItems[id];
            updatePrice();

        }
}

   function updatePrice(){
    total_price=0;
    selectedItems.forEach(element => {
        total_price+=element.price*element.count;
     });
     document.getElementById('total').value=total_price;
     document.getElementById('total_price').innerText=total_price;
   }
    </script>

  <script>

  </script>
  <?php if(session()->has('success')): ?>
    <script>
        console.log('success');
        Swal.fire({
            icon: 'success',
            title: '<?php echo e(session('success_title')); ?>',
            text: '<?php echo e(session('success')); ?>',
            confirmButtonColor:'#1277D1',

        });
    </script>
<?php endif; ?>

<?php if($errors->has('message')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<?php echo e($errors->first('message')); ?>',
        });


    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/products.blade.php ENDPATH**/ ?>