<footer class="footer" role="contentinfo">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-4 mb-md-0">
          <h3><?php echo e(__('main.aboutformshub')); ?></h3>
          <p><?php echo e(__('main.aboutformshub_text')); ?></p>
          
        </div>
        <div class="col-md-7 ms-auto">
          <div class="row site-section pt-0">
            <div class="col-md-4 mb-4 mb-md-0">
              <h3><?php echo e(__('main.navigation')); ?></h3>
              <ul class="list-unstyled">
                <li><a href="<?php echo e(route('pricing')); ?>"><?php echo e(__('main.pricing')); ?></a></li>
                <li><a href="<?php echo e(route('features')); ?>"><?php echo e(__('main.features')); ?></a></li>
                <li><a href="<?php echo e(route('contact')); ?>"><?php echo e(__('main.contactus')); ?></a></li>
                <li><a href="<?php echo e(route('products')); ?>"><?php echo e(__('main.products')); ?></a></li>
              </ul>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
              <h3><?php echo e(__('main.services')); ?></h3>
              <ul class="list-unstyled">
                <li><a href="<?php echo e(route('knowledgebase')); ?>"><?php echo e(__('main.knowledgebase')); ?></a></li>
                <li><a href="<?php echo e(route('terms_conditions')); ?>" target="_blank"><?php echo e(__('main.termsandconditions')); ?></a></li>
                <li><a href="<?php echo e(route('privacypolicy')); ?>" target="_blank"><?php echo e(__('main.privacypolicy')); ?></a></li>

              </ul>
            </div>
            
          </div>
        </div>
      </div>



    </div>
    <div  class="row justify-content-center text-center copyright-section">
        <div class="col-md-7">
          <p class="copyright">&copy; <?php echo e(__('main.copyright',['name'=>'Formshub'])); ?></p>
          <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=SoftLand
          -->
            <?php echo e(__('main.designedby')); ?><a href="http://www.netcore.ae/"> Netcore IT Solutions</a>
          </div>
        </div>
    </div>
  </footer>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('assets/vendor/aos/aos.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

  <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/sweetalert2@11')); ?>"></script>

<?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/includes/footer.blade.php ENDPATH**/ ?>