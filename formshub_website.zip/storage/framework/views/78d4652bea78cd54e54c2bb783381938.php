<?php $__env->startSection('content'); ?>

    <?php
    $title=trans('main.contact_title');
    $text=trans('main.contact_text');
    ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header_section','data' => ['title' => $title,'text' => $text]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header_section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($text)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <section class="section">
      <div class="container">
        <div class="row mb-5 align-items-end">
          <div class="col-md-6" data-aos="fade-up">

            <h2><?php echo e(__('main.form_title')); ?></h2>
            <p class="mb-0"><?php echo e(__('main.form_text')); ?></p>
          </div>

        </div>

        <div class="row">
          <div class="col-md-4 ms-auto order-2" data-aos="fade-up">
            <ul class="list-unstyled">
              <li class="mb-3">
                <strong class="d-block mb-1"><?php echo e(__('main.address')); ?></strong>
                <span><?php echo e(__('main.address_value')); ?></span>
              </li>
              <li class="mb-3">
                <strong class="d-block mb-1"><?php echo e(__('main.phone')); ?></strong>
                <span>+1 232 3235 324</span>
              </li>
              <li class="mb-3">
                <strong class="d-block mb-1"><?php echo e(__('main.email')); ?></strong>
                <span><?php echo e(__('main.email_value')); ?></span>
              </li>
            </ul>
          </div>

          <div class="col-md-6 mb-5 mb-md-0" data-aos="fade-up">
            <form action="<?php echo e(route('sendemail')); ?>" method="post" role="form" id="contactForm" >
               <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-md-6 form-group">
                  <label for="name"><?php echo e(__('main.name')); ?></label>
                  <input type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="name"><?php echo e(__('main.email')); ?></label>
                  <input type="email" class="form-control" name="email" id="email" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-12 form-group mt-3">
                  <label for="name"><?php echo e(__('main.subject')); ?></label>
                  <input type="text" class="form-control" name="subject" id="subject" required>
                </div>
                <div class="col-md-12 form-group mt-3">
                  <label for="name"><?php echo e(__('main.message')); ?></label>
                  <textarea class="form-control" name="message" required></textarea>
                </div>

                

                <div class="col-md-6 form-group mt-2">
                  <input id="submitButton" type="submit" class="btn btn-primary d-block w-100" value="<?php echo e(__('main.sendmessage')); ?>">
                </div>
              </div>

            </form>
          </div>

        </div>
      </div>
    </section>






  <!-- ======= Footer ======= -->
  <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/sweetalert2@11')); ?>"></script>
  <script src="<?php echo e(asset('https://code.jquery.com/jquery-3.6.4.min.js')); ?>"></script>

    <script>
          var translations = <?php echo json_encode(__('main'), 15, 512) ?>;

        $(document).ready(function () {
            $('#contactForm').submit(function () {
                $('#submitButton').prop('disabled', true);
                $('#submitButton').prop('value',"Sending..");
            });
        });
    </script>

   <?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: translations.success,
            text: '<?php echo e(session('success')); ?>',
            confirmButtonColor:'#f3f4f6',
            confirmButtonText:`<h5 style='color:000000;border:0;box-shadow: none;'>ok</h5>`,
        });
    </script>
    <?php endif; ?>

    <?php if($errors->has('message')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: translations.error,
                text: '<?php echo e($errors->first('message')); ?>',
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/contact.blade.php ENDPATH**/ ?>