<!doctype html >
<html >
<head>
   <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body >

    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <main id="main">
           <?php echo $__env->yieldContent('content'); ?>
   </main>

       <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/layouts/app.blade.php ENDPATH**/ ?>