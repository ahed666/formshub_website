<?php $__env->startComponent('mail::message'); ?>
# New Contact Form Submission

Dear Support Team,

You have received a new contact form submission with the following details:

<div style="display: grid; grid-template-columns: 100px 1fr; gap: 10px; font-weight: bold;">
    <div>Name:</div>
    <div><?php echo e($contactData['name']); ?></div>
    <div>Email:</div>
    <div><?php echo e($contactData['email']); ?></div>
    <div>Subject:</div>
    <div><?php echo e($contactData['subject']); ?></div>
    <div>Message:</div>
    <div><?php echo e($contactData['message']); ?></div>
</div>



Thank you for your attention.

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/emails/contact-form.blade.php ENDPATH**/ ?>