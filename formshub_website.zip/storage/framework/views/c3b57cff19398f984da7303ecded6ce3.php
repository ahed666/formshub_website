  <!-- ======= Header ======= -->

  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <!-- End Hero -->
  <?php $__env->startSection('content'); ?>

  <main id="main">


    <?php
        $title= trans('main.kb_title') ;
        $text= trans('main.kb_text') ;
    ?>
     <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header_section','data' => ['title' => $title,'text' => $text]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header_section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($text)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <section class="section p-2">

        <?php $__currentLoopData = $categoriesWithQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="cat-<?php echo e($category->id); ?>" class="faq_cateogry">
                <h6 class="title">
                <?php if(App::getLocale()=="en"): ?>    <?php echo e($category->name); ?>

                <?php else: ?> <?php echo e($category->name_ar); ?>

                <?php endif; ?>
                </h6>
                <?php $__currentLoopData = $category->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <button id="question-<?php echo e($question->id); ?>" onclick="ShowAnswer(<?php echo e($question->id); ?>)"  class="accordion">
                            <?php if(App::getLocale()=="en"): ?>    <?php echo e($question->question); ?>

                            <?php else: ?> <?php echo e($question->question_ar); ?>

                            <?php endif; ?>
                        </button>
                        <div id="answer-<?php echo e($question->id); ?>" class="panel">
                        <p>
                            <?php if(App::getLocale()=="en"): ?><?php echo $question->answer; ?>

                            <?php else: ?> <?php echo e($question->answer_ar); ?>

                            <?php endif; ?>
                        </p>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </section>



  </main><!-- End #main -->
  <script>
    var current_question = <?php echo json_encode($current_question, JSON_HEX_TAG); ?>;
    if(current_question!=null)
    {
        var answer = document.getElementById(`answer-${current_question.id}`);
        var question = document.getElementById(`question-${current_question.id}`);
        question.classList.add("active_faq");
        if (answer.style.display=="block") {
            answer.style.display = "none";
            }
            else {
                answer.style.display = "block";
        }
        scrollToSection(current_question.faq_category_id);
    }

    // knowledge base
    // var acc = document.getElementsByClassName("accordion");
    // var allPanels = document.getElementsByClassName("panel");
    //     var i;
    //     console.log(acc);
    //     for (i = 0; i < acc.length; i++) {

    //     acc[i].addEventListener("click", function() {

    //         for (var j = 0; j < allPanels.length; j++) {
    //             allPanels[j].style.display = "none";
    //         }
    //         this.classList.toggle("active_faq");
    //         var panel = this.nextElementSibling;

    //         if (panel.style.display === "block") {
    //         panel.style.display = "none";
    //         } else {
    //         panel.style.display = "block";
    //         }
    //     });
    // }
    function ShowAnswer(id){
             var answers = document.getElementsByClassName("panel");
             var questions = document.getElementsByClassName("accordion");
            for (var j = 0; j < answers.length; j++) {
                if( answers[j].id!=`answer-${id}`)
                {answers[j].style.display = "none";
                questions[j].classList.remove("active_faq");}
            }

      question=document.getElementById(`question-${id}`);
      question.classList.toggle("active_faq");
      answer=document.getElementById(`answer-${id}`);

      if (answer.style.display == "block") {
        answer.style.display = "none";
            } else {
                answer.style.display = "block";
            }
    }
    function scrollToSection(sectionId) {
      var section = document.getElementById(`cat-${sectionId}`);

      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    }

  </script>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/knowledgebase.blade.php ENDPATH**/ ?>