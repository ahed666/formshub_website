<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between align-items-center">

      <div class="logo">
       <img  src="<?php echo e(asset('assets/img/logos/logo.png')); ?>" alt="">
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="<?php echo e((request()->routeIs('home')) ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"><?php echo e(__('main.home')); ?></a></li>
          <li><a class="<?php echo e((request()->routeIs('features')) ? 'active' : ''); ?>" href="<?php echo e(route('features')); ?>"><?php echo e(__('main.features')); ?></a></li>
          <li><a class="<?php echo e((request()->routeIs('pricing')) ? 'active' : ''); ?>" href="<?php echo e(route('pricing')); ?>"><?php echo e(__('main.pricing')); ?></a></li>
          <li><a class="<?php echo e((request()->routeIs('products')) ? 'active' : ''); ?>" href="<?php echo e(route('products')); ?>"><?php echo e(__('main.products')); ?></a></li>
          <li><a class="<?php echo e((request()->routeIs('knowledgebase')) ? 'active' : ''); ?>" href="<?php echo e(route('knowledgebase')); ?>"><?php echo e(__('main.knowledgebase')); ?></a></li>
          <li><a class="<?php echo e((request()->routeIs('contact')) ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>"><?php echo e(__('main.contactus')); ?></a></li>

          <?php if(App::getLocale()=="ar"): ?>
          <li><a  href="<?php echo e(route('setLocale','en')); ?>">English</a></li>
           <?php else: ?>
           <li><a  href="<?php echo e(route('setLocale','ar')); ?>">العربية</a></li>
           <?php endif; ?>

           <li class="gotoapp_navbar">

                <a href="<?php echo e(config('app.sub_domain_name')); ?>" class=" gotoapp_navbar_button"><?php echo e(__('main.gotoapp_button')); ?></a>

          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>


      </nav><!-- .navbar -->
      


    </div>
  </header>
<?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/includes/header.blade.php ENDPATH**/ ?>