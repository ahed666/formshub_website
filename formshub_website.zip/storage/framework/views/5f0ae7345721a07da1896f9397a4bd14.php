

<?php $__env->startComponent('mail::message'); ?>
    # New Order Notification

    Dear Sales Team,

    A new order has been placed with the following details:

    **Customer Name:** <?php echo e($orderData['customer_name']); ?>

    **Customer Email:** <?php echo e($orderData['customer_email']); ?>

    **Customer Mobile Number:** <?php echo e($orderData['customer_mobile_number']); ?>


    **Ordered Items:**
    <?php $__currentLoopData = $orderData['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        - <?php echo e($item['device_model']); ?>_<?php echo e($item['name']); ?> (<?php echo e($item['quantity']); ?> x <?php echo e($item['price']); ?> AED)
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    **Order Total:** <?php echo e($orderData['total']); ?> AED
    **Order No:** FHORDER-<?php echo e($orderData['id']); ?>


    Thank you for your attention.

    


   <div style="display: flex; justify-content:center; items-align:center">
    <a  style="background-color:#1277D1;padding:8px;color:White;border-radius:20px;text-decoration : none;" href="<?php echo e(url(env('WEBAPP_URL') . '/orders')); ?>">
        View Order
    </a>
   </div>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\formshub_website\resources\views/emails/order-notification.blade.php ENDPATH**/ ?>